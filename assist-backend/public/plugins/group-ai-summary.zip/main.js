/**
 * 群聊 AI 总结插件
 * 在群聊会话的 rong-tools 工具栏最左侧添加「AI总结」按钮
 * 点击按钮后获取最近消息并调用外部 AI 接口进行总结，显示在悬浮面板中
 */

const fs = require('fs');
const path = require('path');

module.exports = {
    // 插件元信息
    name: '群聊AI总结',
    description: '在群聊工具栏添加AI总结按钮，点击后获取最近消息生成群聊动态摘要',
    version: 'dev',
    author: 'zfeng',
    defaultEnabled: false,

    // 客户端配置面板中只保留启用/禁用开关，无其他可配置参数
    defaultConfig: {},

    // 内部运行参数（不暴露给用户配置面板）
    _settings: {
        apiPath: '/api/ai/summary',    // AI 总结接口路径（会拼接到全局服务器地址后面）
        apiKey: '',                    // API Key（可选）
        messageCount: 50,              // 获取最近消息条数
        cacheExpiry: 5 * 60 * 1000,    // 缓存过期时间（毫秒，默认5分钟）
    },

    /**
     * 初始化插件
     */
    async init(config, pluginManager) {
        console.log('[GroupAISummary] 🚀 初始化群聊AI总结插件...');

        // 使用内部硬编码的 _settings，不依赖用户配置
        const settings = this._settings;

        const instance = {
            config: settings,
            widget: null,
            toolbarBtn: null,
            currentTargetId: null,
            currentConversationType: null,
            summaryCache: new Map(),       // targetId -> { summary, timestamp, groupName, msgCount }
            isLoading: false,
        };

        // 等待 document.body 就绪后再执行 DOM 操作
        const self = this;
        const initDOM = () => {
            // 创建总结悬浮面板（初始隐藏）
            self.createSummaryWidget(instance);

            // 注入全局样式
            self.injectStyles();

            // 监听会话切换，动态注入/移除工具栏按钮
            self.observeConversationChange(instance);

            console.log('[GroupAISummary] ✅ 群聊AI总结插件已启动');
            console.log('[GroupAISummary] AI接口路径:', settings.apiPath);
            console.log('[GroupAISummary] 获取消息数:', settings.messageCount);
        };

        if (document.body) {
            initDOM();
        } else {
            // body 尚未就绪，等待 DOMContentLoaded
            const onReady = () => {
                initDOM();
                document.removeEventListener('DOMContentLoaded', onReady);
            };
            document.addEventListener('DOMContentLoaded', onReady);
            // 兜底：如果 DOMContentLoaded 已触发但 body 仍为 null（极端情况），用定时器保底
            setTimeout(() => {
                if (!instance.widget && document.body) {
                    initDOM();
                }
            }, 3000);
        }

        return instance;
    },

    /**
     * 注入全局样式（从外部 styles.css 文件加载）
     */
    injectStyles() {
        if (document.querySelector('#ai-summary-styles')) return;
        try {
            const cssPath = path.join(__dirname, 'styles.css');
            const cssContent = fs.readFileSync(cssPath, 'utf-8');
            const style = document.createElement('style');
            style.id = 'ai-summary-styles';
            style.textContent = cssContent;
            document.head.appendChild(style);
        } catch (e) {
            console.error('[GroupAISummary] 加载样式文件失败:', e);
        }
    },

    /**
     * 监听会话切换，动态注入按钮
     */
    observeConversationChange(instance) {
        const self = this;

        // 监听 hashchange
        const hashHandler = () => {
            self.syncToolbarButton(instance);
        };
        window.addEventListener('hashchange', hashHandler);
        instance._hashHandler = hashHandler;

        // 用 MutationObserver 补充监听（处理初始加载和动态渲染）
        const observer = new MutationObserver(() => {
            self.syncToolbarButton(instance);
        });
        instance._observer = observer;

        // 延迟启动，等待 IM 界面加载完成
        const startObserve = () => {
            const app = document.querySelector('#app') || document.body;
            observer.observe(app, { childList: true, subtree: true });
            self.syncToolbarButton(instance);
        };

        // 分级延迟注入，确保 DOM 就绪
        setTimeout(startObserve, 2000);
        setTimeout(() => self.syncToolbarButton(instance), 4000);
    },

    /**
     * 解析当前路由，获取 conversationType 和 targetId
     */
    parseRoute() {
        const hash = window.location.hash || '';
        const match = hash.match(/conversation\/(\d+)\/([^/?]+)/);
        if (!match) return null;
        return {
            conversationType: parseInt(match[1], 10),
            targetId: match[2],
        };
    },

    /**
     * 同步工具栏按钮状态
     * - 群聊会话：在 rong-tools 最左侧注入按钮
     * - 非群聊：移除按钮
     */
    syncToolbarButton(instance) {
        const route = this.parseRoute();
        const toolbar = document.querySelector('.rong-tools');

        if (!toolbar) return;

        const existingBtn = toolbar.querySelector('#rong-tools-ai-summary-btn');

        // 非群聊场景 → 移除按钮
        if (!route || route.conversationType !== 3) {
            if (existingBtn) existingBtn.remove();
            instance.currentTargetId = null;
            instance.currentConversationType = null;
            return;
        }

        // 更新当前会话信息
        instance.currentTargetId = route.targetId;
        instance.currentConversationType = route.conversationType;

        // 按钮已存在 → 只更新缓存标记（小圆点）
        if (existingBtn) {
            return;
        }

        // 创建按钮并插入到 rong-tools 最左侧
        const btn = document.createElement('button');
        btn.id = 'rong-tools-ai-summary-btn';
        btn.title = 'AI 群聊总结';

        // 使用 base64 SVG 图标（AI 闪光 / sparkle 风格，与导航栏图标风格一致）
        const makeSvg = (color) => `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="${color}"><path d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z"/></svg>`;
        const defaultIcon = btoa(makeSvg(window.PluginTheme ? window.PluginTheme.getNavIconColor() : '#808CA4'));
        const hoverIcon = btoa(makeSvg('#3A6EE7'));

        btn.style.backgroundImage = `url("data:image/svg+xml;base64,${defaultIcon}")`;

        // 悬停效果：图标变蓝 + 微放大
        btn.addEventListener('mouseenter', function () {
            this.style.backgroundImage = `url("data:image/svg+xml;base64,${hoverIcon}")`;
            this.style.transform = 'scale(1.15)';
        });
        btn.addEventListener('mouseleave', function () {
            this.style.backgroundImage = `url("data:image/svg+xml;base64,${defaultIcon}")`;
            this.style.transform = 'scale(1)';
        });

        // 点击事件 → 切换面板显示并触发总结
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.onButtonClick(instance);
        });

        // 插入到最左侧（第一个子元素之前）
        toolbar.insertBefore(btn, toolbar.firstChild);
        instance.toolbarBtn = btn;

        console.log('[GroupAISummary] 📌 已注入AI总结按钮到工具栏');
    },

    /**
     * 按钮点击处理
     */
    onButtonClick(instance) {
        const widget = instance.widget;
        if (!widget) return;

        // 面板已显示 → 关闭
        if (widget.style.display === 'block') {
            widget.style.display = 'none';
            return;
        }

        // 显示面板
        widget.style.display = 'block';

        // 触发总结
        if (instance.currentTargetId && instance.currentConversationType) {
            this.triggerSummary(instance, instance.currentConversationType, instance.currentTargetId);
        }
    },

    /**
     * 创建总结悬浮面板
     */
    createSummaryWidget(instance) {
        const widget = document.createElement('div');
        widget.id = 'group-ai-summary-widget';

        widget.innerHTML = `
            <div id="ai-summary-header">
                <div class="ai-summary-header-left">
                    <span class="ai-summary-header-icon">🤖</span>
                    <span class="ai-summary-header-title">AI 群聊动态</span>
                </div>
                <div class="ai-summary-header-actions">
                    <button id="ai-summary-refresh" class="ai-summary-header-btn" title="刷新">🔄</button>
                    <button id="ai-summary-close" class="ai-summary-header-btn" title="关闭">✕</button>
                </div>
            </div>
            <div id="ai-summary-body">
                <div id="ai-summary-group-info">
                    <div id="ai-summary-group-name"></div>
                    <div id="ai-summary-msg-count"></div>
                </div>
                <div id="ai-summary-content">
                    <div class="ai-summary-placeholder">
                        <div class="ai-summary-placeholder-icon">💬</div>
                        <div>点击工具栏 🤖 按钮开始AI总结</div>
                    </div>
                </div>
                <div id="ai-summary-time"></div>
            </div>
        `;

        document.body.appendChild(widget);
        instance.widget = widget;

        // 实现拖拽
        this.makeDraggable(widget, widget.querySelector('#ai-summary-header'));

        // 绑定按钮事件
        this.bindWidgetEvents(instance);
    },

    /**
     * 绑定面板按钮事件
     */
    bindWidgetEvents(instance) {
        const widget = instance.widget;

        // 刷新按钮
        widget.querySelector('#ai-summary-refresh').addEventListener('click', () => {
            if (instance.currentTargetId && instance.currentConversationType) {
                // 清除缓存强制刷新
                instance.summaryCache.delete(instance.currentTargetId);
                this.triggerSummary(instance, instance.currentConversationType, instance.currentTargetId);
            }
        });

        // 关闭按钮
        widget.querySelector('#ai-summary-close').addEventListener('click', () => {
            widget.style.display = 'none';
        });
    },

    /**
     * 触发总结流程
     */
    async triggerSummary(instance, conversationType, targetId) {
        // 检查缓存
        const cached = instance.summaryCache.get(targetId);
        if (cached && (Date.now() - cached.timestamp) < instance.config.cacheExpiry) {
            console.log('[GroupAISummary] 使用缓存总结');
            this.showSummary(instance, cached.summary, cached.groupName, cached.msgCount);
            return;
        }

        // 显示加载状态
        this.showLoading(instance);

        try {
            // Step 1: 获取群聊最近消息
            const messages = await this.fetchRecentMessages(instance, conversationType, targetId);

            if (!messages || messages.length === 0) {
                this.showEmpty(instance);
                return;
            }

            // 获取群组名称
            const groupName = await this.getGroupName(targetId);

            // Step 2: 发送到 AI 接口进行总结
            const summary = await this.requestAISummary(instance, messages, groupName, targetId);

            // Step 3: 缓存并显示
            instance.summaryCache.set(targetId, {
                summary,
                groupName,
                msgCount: messages.length,
                timestamp: Date.now()
            });

            this.showSummary(instance, summary, groupName, messages.length);


        } catch (error) {
            console.error('[GroupAISummary] ❌ 总结失败:', error);
            this.showError(instance, error.message);
        }
    },

    /**
     * 获取群组名称
     */
    getGroupName(targetId) {
        return new Promise((resolve) => {
            try {
                const RongIM = window.RongIM;
                if (RongIM && RongIM.dataModel && RongIM.dataModel.Group) {
                    RongIM.dataModel.Group.getGroup(targetId, (err, group) => {
                        if (err || !group) {
                            resolve(targetId);
                        } else {
                            resolve(group.name || targetId);
                        }
                    });
                } else {
                    resolve(targetId);
                }
            } catch (e) {
                resolve(targetId);
            }
        });
    },

    /**
     * 获取最近消息
     */
    fetchRecentMessages(instance, conversationType, targetId) {
        return new Promise((resolve, reject) => {
            try {
                const RongIMClient = window.RongIMLib && window.RongIMLib.RongIMClient;
                if (!RongIMClient) {
                    reject(new Error('RongIMClient 未找到'));
                    return;
                }

                const count = instance.config.messageCount || 50;

                // 通过融云 SDK 获取历史消息
                RongIMClient.getInstance().getHistoryMessages(
                    conversationType,
                    targetId,
                    0,          // timestamp = 0 表示从最新消息开始
                    count,
                    {
                        onSuccess: (messageList, hasMore) => {
                            console.log(`[GroupAISummary] 获取到 ${messageList.length} 条消息`);
                            resolve(messageList);
                        },
                        onError: (errorCode) => {
                            console.error('[GroupAISummary] 获取历史消息失败, 错误码:', errorCode);
                            // 如果本地获取失败，尝试服务器
                            RongIMClient.getInstance().getRemoteHistoryMessages(
                                conversationType,
                                targetId,
                                0,
                                count,
                                {
                                    onSuccess: (messageList, hasMore) => {
                                        console.log(`[GroupAISummary] 从服务器获取到 ${messageList.length} 条消息`);
                                        resolve(messageList);
                                    },
                                    onError: (err) => {
                                        reject(new Error(`获取消息失败 (${err})`));
                                    }
                                }
                            );
                        }
                    }
                );
            } catch (error) {
                reject(error);
            }
        });
    },

    /**
     * 批量解析用户 ID 为真实姓名
     * @param {Array} messages - 消息列表
     * @returns {Promise<Map>} userId -> userName 映射
     */
    async resolveUserNames(messages) {
        const userIds = [...new Set(messages.map(m => m.senderUserId).filter(Boolean))];
        const nameMap = new Map();

        const RongIM = window.RongIM;
        if (!RongIM || !RongIM.dataModel || !RongIM.dataModel.User) {
            console.warn('[GroupAISummary] RongIM.dataModel.User 不可用，将使用用户 ID');
            userIds.forEach(id => nameMap.set(id, id));
            return nameMap;
        }

        // 逐个查询用户信息（使用 Promise 包装回调 API）
        const resolveOne = (userId) => new Promise((resolve) => {
            try {
                RongIM.dataModel.User.get(userId, (err, user) => {
                    if (err || !user) {
                        resolve({ id: userId, name: userId });
                    } else {
                        resolve({ id: userId, name: user.name || user.alias || userId });
                    }
                });
            } catch (e) {
                resolve({ id: userId, name: userId });
            }
        });

        const results = await Promise.all(userIds.map(resolveOne));
        results.forEach(({ id, name }) => nameMap.set(id, name));

        console.log(`[GroupAISummary] 已解析 ${nameMap.size} 个用户名称`);
        return nameMap;
    },

    /**
     * 构建发送给服务端的消息文本
     * @param {Array} messages - 原始消息列表
     * @param {Map} userNameMap - userId -> userName 映射
     */
    buildMessageText(messages, userNameMap) {
        const validMessages = messages
            .filter(msg => {
                // 只处理文本类型消息
                const textTypes = ['TextMessage', 'ReferenceMessage'];
                return textTypes.includes(msg.messageType) && msg.content;
            })
            .map(msg => {
                const sender = userNameMap.get(msg.senderUserId) || msg.senderUserId || '未知用户';
                let text = '';

                if (msg.messageType === 'TextMessage') {
                    text = msg.content.content || '';
                } else if (msg.messageType === 'ReferenceMessage') {
                    text = msg.content.text || '';
                }

                // 清理 HTML 标签
                text = text.replace(/<[^>]+>/g, '').trim();

                if (!text) return null;

                return { sender, text, sentTime: msg.sentTime };
            })
            .filter(Boolean);

        if (validMessages.length === 0) return '';

        // 1. 合并同一个人在相近时间（比如3分钟内）的连续发言，降低冗余信息
        const mergedMessages = [];
        let currentMsg = null;

        for (const msg of validMessages) {
            if (!currentMsg) {
                currentMsg = { ...msg, texts: [msg.text] };
            } else {
                const timeDiff = msg.sentTime - currentMsg.sentTime;
                // 同一人且发送间隔小于3分钟 (180,000毫秒)
                if (currentMsg.sender === msg.sender && timeDiff < 3 * 60 * 1000) {
                    currentMsg.texts.push(msg.text);
                    currentMsg.sentTime = msg.sentTime; // 更新时间为合并里的最后一条
                } else {
                    mergedMessages.push(currentMsg);
                    currentMsg = { ...msg, texts: [msg.text] };
                }
            }
        }
        if (currentMsg) {
            mergedMessages.push(currentMsg);
        }

        // 2. 精简时间格式 (如：03-27 15:20) 去除非必要的时间噪音（年份和秒数）
        const formatTime = (timestamp) => {
            const d = new Date(timestamp);
            const m = (d.getMonth() + 1).toString().padStart(2, '0');
            const day = d.getDate().toString().padStart(2, '0');
            const h = d.getHours().toString().padStart(2, '0');
            const min = d.getMinutes().toString().padStart(2, '0');
            return `${m}-${day} ${h}:${min}`;
        };

        // 3. 构建排版更好的组装文本
        const textMessages = mergedMessages.map(msg => {
            const timeStr = formatTime(msg.sentTime);
            // 常见情况下连续发言可以用空格或者句号连接
            const combinedText = msg.texts.join('  '); 
            return `[${timeStr}] ${msg.sender}: ${combinedText}`;
        });

        return textMessages.join('\n');
    },

    /**
     * 调用 AI 总结接口
     */
    async requestAISummary(instance, messages, groupName, targetId) {
        const config = instance.config;

        // Step 1: 解析用户名称
        const userNameMap = await this.resolveUserNames(messages);

        // Step 2: 构建消息文本（使用真实姓名）
        const messageText = this.buildMessageText(messages, userNameMap);

        if (!messageText) {
            return '最近没有文本消息可以总结。';
        }

        // 从全局配置获取服务器地址
        const serverUrl = this.getServerUrl();
        if (!serverUrl) {
            return '⚠️ 服务器地址未配置，请在插件管理中心 → 设置中配置服务器地址。';
        }
        const apiEndpoint = serverUrl.replace(/\/+$/, '') + (config.apiPath || '/api/ai/summary');
        console.log('[GroupAISummary] 请求AI接口:', apiEndpoint);

        try {
            const headers = {
                'Content-Type': 'application/json',
            };

            if (config.apiKey) {
                headers['Authorization'] = `Bearer ${config.apiKey}`;
            }

            // 附加用户标识到请求头
            const currentUserId = this.getCurrentUserId();
            if (currentUserId) {
                headers['X-User-Id'] = currentUserId;
            }

            // 客户端超时设置（最大60s等待）
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 60000);

            // 只传递原始数据，提示词由服务端拼装
            const response = await fetch(apiEndpoint, {
                method: 'POST',
                headers,
                body: JSON.stringify({
                    groupId: targetId,
                    groupName: groupName,
                    messageCount: messages.length,
                    rawMessages: messageText,
                }),
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`AI接口返回错误: ${response.status} ${response.statusText}`);
            }

            const result = await response.json();

            // 兼容多种返回格式
            const summary = result.summary
                || result.content
                || result.data?.summary
                || result.data?.content
                || result.choices?.[0]?.message?.content       // OpenAI 格式
                || result.result
                || result.output
                || JSON.stringify(result);

            return summary;

        } catch (error) {
            console.error('[GroupAISummary] AI 接口调用失败:', error);
            
            if (error.name === 'AbortError') {
                throw new Error('客户端请求超时（等待超过 60 秒），服务端可能正在处理队列，请稍后再试。');
            }
            
            // 降级处理：本地生成简要统计
            return this.generateLocalSummary(messages, groupName);
        }
    },

    /**
     * 获取当前登录用户ID
     */
    getCurrentUserId() {
        try {
            if (window.RongIM && window.RongIM.instance) {
                const auth = window.RongIM.instance.auth;
                if (auth && auth.id) return auth.id;
            }
        } catch (e) {}
        try {
            const client = window.RongIMLib && window.RongIMLib.RongIMClient.getInstance();
            if (client && typeof client.getCurrentUserId === 'function') {
                return client.getCurrentUserId();
            }
        } catch (e) {}
        return null;
    },

    /**
     * 获取全局服务器地址
     * 从插件管理中心的设置中读取服务器地址
     */
    getServerUrl() {
        try {
            if (window.PluginManager && typeof window.PluginManager.getServerUrl === 'function') {
                return window.PluginManager.getServerUrl() || null;
            }
        } catch (e) {
            console.warn('[GroupAISummary] 获取服务器地址失败:', e);
        }
        return null;
    },

    /**
     * 本地降级总结（AI 接口不可用时使用）
     */
    generateLocalSummary(messages, groupName) {
        const textMessages = messages.filter(m =>
            m.messageType === 'TextMessage' && m.content?.content
        );

        const senders = new Set(messages.map(m => m.senderUserId));
        const timeRange = messages.length > 0
            ? {
                start: new Date(Math.min(...messages.map(m => m.sentTime))).toLocaleString('zh-CN'),
                end: new Date(Math.max(...messages.map(m => m.sentTime))).toLocaleString('zh-CN')
            }
            : null;

        let summary = `⚠️ AI接口暂不可用，以下为本地统计：\n\n`;
        summary += `📋 群聊名称：${groupName}\n`;
        summary += `💬 消息总数：${messages.length} 条\n`;
        summary += `📝 文本消息：${textMessages.length} 条\n`;
        summary += `👥 参与人数：${senders.size} 人\n`;

        if (timeRange) {
            summary += `⏰ 时间范围：\n  ${timeRange.start}\n  ~ ${timeRange.end}`;
        }

        return summary;
    },

    // ======================== UI 显示方法 ========================

    /**
     * 显示加载状态
     */
    showLoading(instance) {
        if (!instance.widget) return;
        instance.isLoading = true;
        instance.widget.style.display = 'block';

        const content = instance.widget.querySelector('#ai-summary-content');
        content.innerHTML = `
            <div class="ai-summary-loading">
                <div class="ai-summary-spinner"></div>
                <div class="ai-summary-loading-text">正在分析群聊消息... <span id="ai-summary-wait-time">(0s)</span></div>
                <div class="ai-summary-loading-subtext">AI 正在总结中，请稍候</div>
            </div>
        `;

        instance.widget.querySelector('#ai-summary-group-info').style.display = 'none';
        instance.widget.querySelector('#ai-summary-time').style.display = 'none';

        if (instance._loadingTimer) {
            clearInterval(instance._loadingTimer);
        }
        let waitTime = 0;
        instance._loadingTimer = setInterval(() => {
            waitTime++;
            const timeEl = instance.widget.querySelector('#ai-summary-wait-time');
            if (timeEl) {
                timeEl.textContent = `(${waitTime}s)`;
            }
        }, 1000);
    },

    /**
     * 显示总结结果
     */
    showSummary(instance, summary, groupName, msgCount) {
        if (!instance.widget) return;
        instance.isLoading = false;
        instance.widget.style.display = 'block';
        
        if (instance._loadingTimer) {
            clearInterval(instance._loadingTimer);
            instance._loadingTimer = null;
        }

        // 群组信息
        const groupInfo = instance.widget.querySelector('#ai-summary-group-info');
        groupInfo.style.display = 'block';
        instance.widget.querySelector('#ai-summary-group-name').textContent = `📌 ${groupName}`;
        instance.widget.querySelector('#ai-summary-msg-count').textContent = `基于最近 ${msgCount} 条消息分析`;

        // 总结内容
        const content = instance.widget.querySelector('#ai-summary-content');
        content.innerHTML = this.formatSummary(summary);

        // 更新时间
        const timeEl = instance.widget.querySelector('#ai-summary-time');
        timeEl.style.display = 'block';
        timeEl.textContent = `更新于 ${new Date().toLocaleTimeString('zh-CN')}`;
    },

    /**
     * 格式化总结内容为 HTML
     */
    formatSummary(summary) {
        if (!summary) return '<p style="color: #999;">暂无总结内容</p>';

        let text = summary
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');

        // 先压缩多余空行：3 个及以上连续换行 → 2 个
        text = text.replace(/\n{3,}/g, '\n\n');
        // 去除首尾空白
        text = text.trim();

        let html = text
            // emoji 标题行加粗
            .replace(/^([\u{1F300}-\u{1F9FF}].*?)$/gmu, '<div class="ai-summary-section-title">$1</div>')
            // 数字编号行（如 1. / 2、）
            .replace(/^(\d+[\.、].*)$/gm, '<div class="ai-summary-numbered-item">$1</div>')
            // 子项（- 或 • 开头）
            .replace(/^[-•]\s(.*)$/gm, '<div class="ai-summary-sub-item">· $1</div>')
            // ** 加粗 **
            .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

        // 清理被 div 包裹的行之间残留的换行
        html = html.replace(/<\/div>\n+<div/g, '</div><div');
        // 双换行 → 段落间距
        html = html.replace(/\n\n/g, '<div class="ai-summary-paragraph-gap"></div>');
        // 单换行 → 换行
        html = html.replace(/\n/g, '<br>');

        return `<div class="ai-summary-formatted">${html}</div>`;
    },

    /**
     * 显示空消息提示
     */
    showEmpty(instance) {
        if (!instance.widget) return;
        instance.isLoading = false;
        instance.widget.style.display = 'block';

        if (instance._loadingTimer) {
            clearInterval(instance._loadingTimer);
            instance._loadingTimer = null;
        }

        const content = instance.widget.querySelector('#ai-summary-content');
        content.innerHTML = `
            <div class="ai-summary-empty">
                <div class="ai-summary-empty-icon">📭</div>
                <div>该群聊暂无最近消息</div>
            </div>
        `;
    },

    /**
     * 显示错误提示
     */
    showError(instance, errorMsg) {
        if (!instance.widget) return;
        instance.isLoading = false;
        instance.widget.style.display = 'block';

        if (instance._loadingTimer) {
            clearInterval(instance._loadingTimer);
            instance._loadingTimer = null;
        }

        const content = instance.widget.querySelector('#ai-summary-content');
        content.innerHTML = `
            <div class="ai-summary-error">
                <div class="ai-summary-error-icon">⚠️</div>
                <div class="ai-summary-error-text">总结失败</div>
                <div class="ai-summary-error-detail">${errorMsg || '未知错误'}</div>
                <button class="ai-summary-retry-btn" onclick="document.querySelector('#ai-summary-refresh').click()">重试</button>
            </div>
        `;
    },

    // ======================== 通用工具方法 ========================

    /**
     * 使元素可拖拽
     */
    makeDraggable(element, handle) {
        let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

        (handle || element).onmousedown = dragMouseDown;

        function dragMouseDown(e) {
            if (e.target.tagName === 'BUTTON') return;
            e = e || window.event;
            e.preventDefault();
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            element.style.top = (element.offsetTop - pos2) + 'px';
            element.style.left = (element.offsetLeft - pos1) + 'px';
            element.style.right = 'auto';
        }

        function closeDragElement() {
            document.onmouseup = null;
            document.onmousemove = null;
        }
    },

    /**
     * 销毁插件
     */
    async destroy(instance) {
        console.log('[GroupAISummary] 🔄 销毁群聊AI总结插件...');

        if (instance._hashHandler) {
            window.removeEventListener('hashchange', instance._hashHandler);
        }

        if (instance._observer) {
            instance._observer.disconnect();
        }

        if (instance._loadingTimer) {
            clearInterval(instance._loadingTimer);
            instance._loadingTimer = null;
        }

        // 移除工具栏按钮
        const btn = document.querySelector('#rong-tools-ai-summary-btn');
        if (btn) btn.remove();

        // 移除面板
        if (instance.widget) {
            instance.widget.remove();
        }

        // 移除样式
        const style = document.querySelector('#ai-summary-styles');
        if (style) style.remove();

        console.log('[GroupAISummary] ✅ 已销毁');
    }
};
