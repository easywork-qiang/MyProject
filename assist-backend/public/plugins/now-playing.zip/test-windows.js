/**
 * 验证 now-playing 插件的 Windows SMTC 集成
 * 模拟插件 init → 轮询 → 读取 的完整流程
 */
const plugin = require('./main.js');
const fs = require('fs');

async function test() {
    console.log('=== 验证 NowPlaying 插件 Windows SMTC 集成 ===\n');
    console.log(`平台: ${process.platform}\n`);

    // 模拟 init (不实际调用 API，只测试 SMTC 读取)
    const fakeConfig = {};

    // 1. 测试 SMTC 脚本生成
    const path = require('path');
    const cacheDir = path.join(__dirname, 'cache');
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

    const scriptPath = path.join(cacheDir, 'smtc_reader.ps1');
    const dataFile = path.join(cacheDir, 'now-playing.json');

    console.log('1️⃣  生成 SMTC 脚本...');
    plugin.createSmtcScript(scriptPath, dataFile);
    console.log(`   ✅ 脚本已生成: ${scriptPath}`);

    // 2. 执行 SMTC 脚本
    console.log('\n2️⃣  执行 SMTC 脚本...');
    const instance = { smtcScriptPath: scriptPath, dataFile, lastSong: '' };
    try {
        plugin.execSmtcScript(instance);
        console.log('   ✅ 脚本执行成功');
    } catch (e) {
        console.error('   ❌ 脚本执行失败:', e.message);
        process.exit(1);
    }

    // 3. 读取结果
    console.log('\n3️⃣  读取结果文件...');
    if (fs.existsSync(dataFile)) {
        let content = fs.readFileSync(dataFile, 'utf-8').replace(/^\uFEFF/, '').trim();
        console.log(`   原始内容: ${content}`);

        const data = JSON.parse(content);
        if (data.playing) {
            console.log(`\n   🎵 正在播放:`);
            console.log(`      歌曲: ${data.title}`);
            console.log(`      歌手: ${data.artist}`);
            console.log(`      专辑: ${data.album}`);
            console.log(`      来源: ${data.source}`);

            // 4. 测试状态文本生成
            const statusText = plugin.truncateStatusText(data.title, data.artist, plugin.DEFAULT_FORMAT, 30);
            console.log(`\n   📝 状态文本: "${statusText}" (${statusText.length}字)`);
        } else {
            console.log('\n   ⏸️ 当前没有正在播放的音乐');
        }
    } else {
        console.log('   ❌ 结果文件不存在');
    }

    // 清理测试文件
    try { fs.unlinkSync(dataFile); } catch (e) {}

    console.log('\n✅ 集成验证完成！');
}

test().catch(e => console.error('测试失败:', e));
