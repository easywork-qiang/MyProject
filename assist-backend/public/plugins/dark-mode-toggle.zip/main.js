/**
 * 日夜间模式切换插件 v4.0
 * 支持三种模式：白天 / 夜间 / 跟随系统（类似 QQ）
 * 通过配置面板的下拉选择切换模式
 * 基于融云 IM 源码的真实 CSS 类名 + QQ 风格中性灰色调
 *
 * 核心颜色映射（亮 → 暗，参考 QQ 夜间模式）:
 *   #ececed (导航栏背景)      → #1e1e1e
 *   #f9f9fa (会话列表背景)    → #262626
 *   #fff    (主区域/白色背景) → #2b2b2b
 *   #fbfbfd (聊天区背景)      → #2b2b2b
 *   #cae7fd (自己消息气泡)    → #3b3b3b
 *   #e0e8f2 (选中/hover 高亮) → #3a3a3a
 *   #333    (主文字色)        → #d4d4d4
 *   #777    (次要文字色)      → #8a8a8a
 *   #ececed (分割线)          → #3a3a3a
 */

module.exports = {
    name: '日夜间模式',
    description: '支持白天/夜间/跟随系统三种模式',
    version: 'dev',
    author: 'zfeng',
    defaultEnabled: false,

    defaultConfig: {
        mode: 'system',   // 'light' | 'dark' | 'system'
    },

    // 配置元数据：告诉配置面板如何渲染 mode 字段
    configMeta: {
        mode: {
            label: '🌗 显示模式',
            options: [
                { value: 'system', label: '跟随系统' },
                { value: 'light', label: '白天' },
                { value: 'dark',  label: '夜间' },

            ]
        }
    },

    // ---- 内部常量 ----
    STYLE_ID: 'dark-mode-plugin-styles',
    TRANSITION_STYLE_ID: 'dark-mode-transition-style',

    // ========================================================================
    //  暗色模式 CSS —— 基于 rong192 源码中的实际类名精确编写
    // ========================================================================
    _getDarkModeCSS() {
        return `
/* ========================================================
   0. 全局变量 & body  (QQ 风格中性灰)
   ======================================================== */
html[data-theme="dark"] {
    color-scheme: dark;
}
html[data-theme="dark"] body {
    background-color: #191919 !important;
}

/* ========================================================
   1. 顶层容器 .rong-im / .rong-common / .rong-im-inner
   ======================================================== */
html[data-theme="dark"] .rong-im,
html[data-theme="dark"] .rong-common {
    color: #d4d4d4 !important;
    background-color: #191919 !important;
}
html[data-theme="dark"] .rong-im-inner {
    background-color: #191919 !important;
}

/* 链接 */
html[data-theme="dark"] .rong-im a,
html[data-theme="dark"] .rong-common a {
    color: #ffffffff !important;
}
html[data-theme="dark"] .rong-im a:hover,
html[data-theme="dark"] .rong-common a:hover {
    color: #56b0ff !important;
}

/* ========================================================
   2. 左侧导航栏 .rong-nav
   QQ: 最深背景 ≈ #1e1e1e
   ======================================================== */
html[data-theme="dark"] .rong-nav {
    background: #1e1e1e !important;
    border-left-color: #2c2c2c !important;
    border-bottom-color: #2c2c2c !important;
}
html[data-theme="dark"] .rong-nav-tab li:hover {
    background-color: rgba(255,255,255,0.06) !important;
}
html[data-theme="dark"] .rong-nav-status-menu {
    background: #303030 !important;
    box-shadow: 0 2px 12px rgba(0,0,0,0.5) !important;
}
html[data-theme="dark"] .rong-nav-status-menu li:hover {
    background-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-nav-status-menu .rong-nav-status-selected {
    background-color: #363636 !important;
}

/* 个人中心面板 */
html[data-theme="dark"] .nav-personal-center {
    background: #2f2f2f !important;
}
html[data-theme="dark"] .nav-personal-center .user-info p {
    color: #ffffff !important;
}
html[data-theme="dark"] .nav-personal-center .menu .item {
    color: #ffffff !important;
}
html[data-theme="dark"] .nav-personal-center .user {
    border-bottom: 0 !important;
}

html[data-theme="dark"] .members-list .name{
    color: #ffffff !important;
}

/* ========================================================
   3. 标题栏 .rong-titlebar (Windows/Linux)
   ======================================================== */
html[data-theme="dark"] .rong-authed .rong-titlebar {
    background: #2c2c2c !important;
    border-color: #2c2c2c !important;
}

/* ========================================================
   4. 会话列表侧栏 .rong-list
   QQ: ≈ #262626
   ======================================================== */
html[data-theme="dark"] .rong-list {
    background: #262626 !important;
    border-right-color: #2c2c2c !important;
    border-bottom-color: #2c2c2c !important;
}

/* 会话列表项 */
html[data-theme="dark"] .rong-conversation-item:hover {
    background-color: #333333 !important;
}
html[data-theme="dark"] .rong-conversation-list .rong-selected {
    background-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-conversation-name em {
    color: #ffffffff !important;
}
html[data-theme="dark"] .rong-conversation-message {
    color: #ffffffff !important;
}
html[data-theme="dark"] .rong-conversation-time {
    color: #ffffffff !important;
}

/* ========================================================
   5. 欢迎页 .rong-welcome
   ======================================================== */
html[data-theme="dark"] .rong-welcome {
    background-color: #2b2b2b !important;
    border-right-color: #2c2c2c !important;
    border-bottom-color: #2c2c2c !important;
}
html[data-theme="dark"] .rong-welcome-bd {
    color: #ffffffff !important;
}

/* ========================================================
   6. 主聊天区域 .rong-main
   QQ: ≈ #2b2b2b
   ======================================================== */
html[data-theme="dark"] .rong-main {
    background: #2b2b2b !important;
    border-right-color: #2c2c2c !important;
    border-bottom-color: #2c2c2c !important;
}
html[data-theme="dark"] .rong-main-hd {
    border-bottom-color: #3a3a3a !important;
    background-color: #2b2b2b !important;
}

/* ========================================================
   7. 聊天会话区 .rong-conversation
   ======================================================== */
html[data-theme="dark"] .rong-conversation-hd {
    border-bottom-color: #3a3a3a !important;
    background-color: #2b2b2b !important;
}
html[data-theme="dark"] .rong-conversation-content {
    background-color: #2b2b2b !important;
}
html[data-theme="dark"] .rong-conversation-tip {
    color: #707070 !important;
}
html[data-theme="dark"] .rong-conversation-one-username,
html[data-theme="dark"] .rong-conversation-one-username a {
    color: #ffffffff !important;
}

/* ========================================================
   8. 消息气泡 (QQ 风格：他人和自己都用中性灰色)
   ======================================================== */
/* 他人消息 */
html[data-theme="dark"] .rong-conversation-other .rong-message .rong-conversation-one-message {
    background: #3b3b3b !important;
    border-color: #3b3b3b !important;
    color: #ffffffff !important;
}
html[data-theme="dark"] .rong-conversation-other .rong-conversation-one-message:after {
    border-right-color: #3b3b3b !important;
}
html[data-theme="dark"] .rong-conversation-other .rong-conversation-one-message:before {
    border-right-color: #3b3b3b !important;
}

/* 自己消息 — QQ 用略亮的灰而非蓝色 */
html[data-theme="dark"] .rong-conversation-me .rong-textmessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-referencemessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-rccombinemessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-groupnoticenotifymessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-voicemessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-videomessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-audiomessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-videosummarymessage .rong-conversation-one-message,
html[data-theme="dark"] .rong-conversation-me .rong-sharescreenmessage .rong-conversation-one-message {
    background: #4a4a4a !important;
    border-color: #4a4a4a !important;
    color: #e8e8e8 !important;
}
html[data-theme="dark"] .rong-conversation-me .rong-textmessage .rong-conversation-one-message:before,
html[data-theme="dark"] .rong-conversation-me .rong-referencemessage .rong-conversation-one-message:before,
html[data-theme="dark"] .rong-conversation-me .rong-rccombinemessage .rong-conversation-one-message:before,
html[data-theme="dark"] .rong-conversation-me .rong-voicemessage .rong-conversation-one-message:before {
    border-left-color: #4a4a4a !important;
}

/* 名片消息 */
html[data-theme="dark"] .rong-cardmessage .rong-conversation-one-message {
    background-color: #3b3b3b !important;
    border-color: #3b3b3b !important;
}

/* 文件消息 */
html[data-theme="dark"] .rong-file {
    background-color: #3b3b3b !important;
}
html[data-theme="dark"] .rong-conversation-one-message.rong-file {
    border-color: #3b3b3b !important;
}

/* 合并消息 */
html[data-theme="dark"] .rong-combine-message-title {
    color: #d4d4d4 !important;
}
html[data-theme="dark"] .rong-message-item {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-combine-bottom {
    border-top-color: #4a4a4a !important;
}

/* ========================================================
   9. 编辑器 / 输入区 .rong-conversation-editor
   ======================================================== */
html[data-theme="dark"] .rong-conversation-editor {
    background: #2b2b2b !important;
    border-top-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-conversation-field textarea {
    color: #d4d4d4 !important;
    background-color: transparent !important;
}

/* 工具栏 .rong-toolbar */
html[data-theme="dark"] .rong-toolbar {
    background-color: #2b2b2b !important;
}

/* 表情面板 */
html[data-theme="dark"] .rong-emoji-panel {
    background: #303030 !important;
    box-shadow: 0 2px 12px rgba(0,0,0,0.4) !important;
}
html[data-theme="dark"] .rong-emoji-item:hover {
    border-color: #444444 !important;
    background-color: #444444 !important;
}
html[data-theme="dark"] .rong-emoji-list {
    background-color: #303030 !important;
    border-top: 1px solid #303030 !important;
}

/* 顶部工具按钮栏 .rong-tools */
html[data-theme="dark"] .rong-tools {
    background-color: transparent !important;
}

/* ========================================================
   10. 搜索框 .rong-search
   ======================================================== */
html[data-theme="dark"] .rong-field-search,
html[data-theme="dark"] .rong-field {
    background-color: #333333 !important;
    border-color: #3f3f3f !important;
    color: #d4d4d4 !important;
}
html[data-theme="dark"] .rong-search-result {
    background: #262626 !important;
    border-right-color: #2c2c2c !important;
}
html[data-theme="dark"] .rong-search-result .rong-group-userlist-bd li:hover {
    background-color: #333333 !important;
}
html[data-theme="dark"] .rong-search-empty {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-search-summary {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-search-record {
    background-color: #303030 !important;
    border-color: #3f3f3f !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.4) !important;
}
html[data-theme="dark"] .rong-search-record .rong-search-record-list .rong-search-item:hover {
    background-color: #3a3a3a !important;
}

/* ========================================================
   11. 弹窗 / 对话框 .rong-dialog
   ======================================================== */
html[data-theme="dark"] .rong-dialog-inner {
    background: #2f2f2f !important;
    border-color: #3f3f3f !important;
    box-shadow: 0 4px 16px rgba(0,0,0,0.5) !important;
}
html[data-theme="dark"] .rong-dialog-hd {
    background: #292929 !important;
    border-bottom-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-dialog-title {
    color: #d4d4d4 !important;
}

/* 用户信息对话框文字颜色 */
html[data-theme="dark"] .rong-im.theme-theme1 .rong-dialog .user-hd > p {
    color: #ffffff !important;
}
html[data-theme="dark"] .rong-im.theme-theme1 .rong-dialog .user-hd > .user-all-status {
    color: #ffffff !important;
}
html[data-theme="dark"] .rong-im.theme-theme1 .rong-dialog ul > li {
    color: #ffffff !important;
}
html[data-theme="dark"] .rong-im.theme-theme1 .rong-dialog .user-info-box > ul > li > span {
    color: #ffffff !important;
}

/* 聊天记录面板文字颜色 */
html[data-theme="dark"] .rong-history .rong-history-item-bd em {
    color: #ffffff !important;
}
html[data-theme="dark"] .rong-history .rong-history-item-hd {
    color: #ffffff !important;
}

/* 聊天记录面板背景 */
html[data-theme="dark"] .rong-history-selected-image .rong-history-main .rong-history-pc > ul > li > div {
    background: #2f2f2f !important;
}
html[data-theme="dark"] .rong-history {
    background: #2f2f2f !important;
}
html[data-theme="dark"] .rong-history-selected-image .rong-history-main .rong-history-time {
    background: #2f2f2f !important;
}

/* 会话设置面板背景 */
html[data-theme="dark"] .rong-conversation-setting {
    background: #2f2f2f !important;
    border-left: #3a3a3a !important;
}
html[data-theme="dark"] .rong-conversation-setting-user {
    background: #2f2f2f !important;
}
html[data-theme="dark"] .rong-conversation-setting-toolbar {
    background: #2f2f2f !important;
}
html[data-theme="dark"] .rong-conversation-setting-userinfo {
    background: #2f2f2f !important;
}
html[data-theme="dark"] .rong-conversation-setting-userinfo ul > li > span {
    color: #ffffff !important;
}

html[data-theme="dark"] .rong-conversation-setting-groupinfo {
    background: #2f2f2f !important;
}

/* 消息中心面板 */
html[data-theme="dark"] .epoint-msg-center {
    border-left: 0 !important;
}
html[data-theme="dark"] .epoint-msg-center .msg-tabs {
    background-color: #2f2f2f !important;
}
html[data-theme="dark"] .epoint-msg-center .msg-content {
    background-color: #2f2f2f !important;   
}
html[data-theme="dark"] .epoint-msg-center .msg-item-link {
    color: #fff !important;
}
html[data-theme="dark"] .epoint-msg-center .msg-item-title {
    color: #fff !important;
}
html[data-theme="dark"] .epoint-msg-center .msg-type-name {
    color: #fff !important;
}
html[data-theme="dark"] .epoint-msg-center .msg-item-container {
    background-color: #2f2f2f !important;
}

html[data-theme="dark"] .epoint-msg-center .msgopera-tab.active {
    color: #fff !important;
}

/* ========================================================
   12. 右键菜单 .rong-menu
   ======================================================== */
html[data-theme="dark"] .rong-menu {
    background: #303030 !important;
    box-shadow: 0 2px 12px rgba(0,0,0,0.5) !important;
    color: #d4d4d4 !important;
}
html[data-theme="dark"] .rong-menu li:hover,
html[data-theme="dark"] .rong-menu .rong-selected {
    background: #3a3a3a !important;
}

/* ========================================================
   13. @ 提及面板 .rong-at
   ======================================================== */
html[data-theme="dark"] .rong-at {
    background: #303030 !important;
    box-shadow: 0 2px 12px rgba(0,0,0,0.5) !important;
}
html[data-theme="dark"] .rong-at li:hover,
html[data-theme="dark"] .rong-at .rong-selected {
    background: #3a3a3a !important;
}

/* ========================================================
   14. 按钮 .rong-button
   ======================================================== */
html[data-theme="dark"] .rong-button {
    background-color: #333333 !important;
    border-color: #4a4a4a !important;
    color: #aaaaaa !important;
}
html[data-theme="dark"] .rong-button:hover {
    color: #56b0ff !important;
}

/* ========================================================
   15. 用户详情卡片 .rong-user
   ======================================================== */
html[data-theme="dark"] .rong-user-hd {
    background: #292929 !important;
}
html[data-theme="dark"] .rong-user-bd {
    background-color: #2f2f2f !important;
}
html[data-theme="dark"] .rong-user-detail label {
    color: #8a8a8a !important;
}

/* ========================================================
   16. 联系人 / 组织架构
   ======================================================== */
html[data-theme="dark"] .rong-contact-hd {
    border-bottom-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-contact-child:before {
    border-left-color: #3f3f3f !important;
}
html[data-theme="dark"] .rong-contact-child a:before {
    background: #3f3f3f !important;
}
html[data-theme="dark"] .rong-contact-child .rong-selected:before {
    background-color: #56b0ff !important;
}
html[data-theme="dark"] .rong-contact-content {
    background-color: #262626 !important;
}
html[data-theme="dark"] .rong-contact-subclass-hd {
    background-color: #292929 !important;
}

/* ========================================================
   17. 设置面板
   ======================================================== */
html[data-theme="dark"] .rong-setting-aside {
    border-right-color: #3a3a3a !important;
    background-color: #292929 !important;
}
html[data-theme="dark"] .rong-system {
    background-color: #2f2f2f !important;
}

/* ========================================================
   18. 个人资料 / Profile 组件
   ======================================================== */
html[data-theme="dark"] .rong-profile-status,
html[data-theme="dark"] .rong-profile-count {
    color: #8a8a8a !important;
}

/* ========================================================
   19. 开关组件 .rong-switch
   ======================================================== */
html[data-theme="dark"] .rong-switch i {
    background: #3a3a3a !important;
    border-color: #4a4a4a !important;
}
html[data-theme="dark"] .rong-switch i:before {
    background: #5a5a5a !important;
}

/* ========================================================
   20. Tag 标签
   ======================================================== */
html[data-theme="dark"] .rong-tag {
    background: #3a7abf !important;
}

/* ========================================================
   21. 消息 Toast 提示
   ======================================================== */
html[data-theme="dark"] .rong-messagetoast-error {
    background: #4a2020 !important;
    color: #ff8888 !important;
}
html[data-theme="dark"] .rong-messagetoast-success {
    background: #1a3a1a !important;
    color: #66cc66 !important;
}

/* ========================================================
   22. 分割线 / 通用 border
   ======================================================== */
html[data-theme="dark"] .rong-menu-line {
    border-bottom-color: #3f3f3f !important;
}

/* ========================================================
   23. 下拉框
   ======================================================== */
html[data-theme="dark"] .rong-search-dropdown {
    background: #303030 !important;
    box-shadow: 0 2px 12px rgba(0,0,0,0.5) !important;
}
html[data-theme="dark"] .rong-search-dropdown:before {
    border-left-color: #3f3f3f !important;
    border-top-color: #3f3f3f !important;
    background: #303030 !important;
}

/* ========================================================
   24. 新消息提醒条
   ======================================================== */
html[data-theme="dark"] .rong-new-message a {
    background: #444444 !important;
}

/* ========================================================
   25. 公众号菜单区域
   ======================================================== */
html[data-theme="dark"] .rong-conversation-public-menu {
    background: #2b2b2b !important;
    border-top-color: #3a3a3a !important;
}

/* ========================================================
   26. 连接失败提示条
   ======================================================== */
html[data-theme="dark"] .rong-status-fail {
    background: #3a2020 !important;
    color: #cc8888 !important;
}

/* ========================================================
   27. 选择框 .rong-select
   ======================================================== */
html[data-theme="dark"] .rong-select select {
    background-color: #333333 !important;
    border-color: #4a4a4a !important;
    color: #aaaaaa !important;
}

/* ========================================================
   28. 通用输入元素
   ======================================================== */
html[data-theme="dark"] .rong-im input,
html[data-theme="dark"] .rong-im textarea,
html[data-theme="dark"] .rong-im select,
html[data-theme="dark"] .rong-common input,
html[data-theme="dark"] .rong-common textarea,
html[data-theme="dark"] .rong-common select {
    background-color: #333333 !important;
    color: #d4d4d4 !important;
    border-color: #4a4a4a !important;
}

/* ========================================================
   29. 群组设置面板（右侧展开）
   ======================================================== */
html[data-theme="dark"] .rong-group-setting {
    background-color: #2b2b2b !important;
    border-left-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-group-setting-hd {
    border-bottom-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-group-userlist-bd li:hover {
    background-color: #333333 !important;
}

/* ========================================================
   30. 空白页 / 无内容状态
   ======================================================== */
html[data-theme="dark"] .rong-empty {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-empty-contact {
    background-color: #2b2b2b !important;
}

/* ========================================================
   31. 滚动条
   ======================================================== */
html[data-theme="dark"] .rong-im ::-webkit-scrollbar-thumb,
html[data-theme="dark"] .rong-common ::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.15) !important;
}
html[data-theme="dark"] .rong-im ::-webkit-scrollbar-thumb:hover,
html[data-theme="dark"] .rong-common ::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.3) !important;
}
html[data-theme="dark"] .rong-im ::-webkit-scrollbar-track,
html[data-theme="dark"] .rong-common ::-webkit-scrollbar-track {
    background: transparent !important;
}

/* ========================================================
   32. 自定义下拉选择
   ======================================================== */
html[data-theme="dark"] .rong-custom-select,
html[data-theme="dark"] .rong-custom-option {
    background-color: #333333 !important;
    color: #aaaaaa !important;
}

/* ========================================================
   33. 置顶标识 (三角形保持蓝色不变)
   ======================================================== */

/* ========================================================
   34. 草稿/未读红色文字保持不变
   ======================================================== */

/* ========================================================
   35. 文件进度条
   ======================================================== */
html[data-theme="dark"] .rong-file-progress {
    background: #3f3f3f !important;
}

/* ========================================================
   36. 合并消息对话框
   ======================================================== */
html[data-theme="dark"] .rong-combine-dialog-content {
    background-color: #2f2f2f !important;
}

/* ========================================================
   37. 插件管理面板适配
   ======================================================== */
html[data-theme="dark"] #plugin-manager-panel {
    background-color: #262626 !important;
    color: #d4d4d4 !important;
}
html[data-theme="dark"] #plugin-manager-panel div[style*="background"] {
    background-color: #2f2f2f !important;
}

/* ========================================================
   38. Quill 富文本编辑器区域
   ======================================================== */
html[data-theme="dark"] .ql-editor {
    color: #d4d4d4 !important;
    background-color: #2b2b2b !important;
}
html[data-theme="dark"] .ql-editor.ql-blank::before {
    color: #666666 !important;
}
html[data-theme="dark"] .ql-toolbar {
    border-color: #3a3a3a !important;
    background-color: #2b2b2b !important;
}

/* ========================================================
   39. 已读回执弹窗
   ======================================================== */
html[data-theme="dark"] .rong-ack-tab {
    border-color: #4a4a4a !important;
}

/* ========================================================
   40. 图片保持原色
   ======================================================== */

/* ========================================================
   41. 截图选项面板
   ======================================================== */
html[data-theme="dark"] .rong-screenshot-option {
    background: #303030 !important;
    border-color: #3f3f3f !important;
    box-shadow: 0 2px 12px rgba(0,0,0,0.5) !important;
}

/* ========================================================
   42. 搜索按钮的下拉菜单
   ======================================================== */
html[data-theme="dark"] .rong-search-add button {
    background-color: #333333 !important;
}

/* ========================================================
   43. 公众号多条图文消息
   ======================================================== */
html[data-theme="dark"] .rong-publicservicerichcontentmessage,
html[data-theme="dark"] .rong-publicservicemultirichcontentmessage {
    background-color: #3b3b3b !important;
}

/* ========================================================
   44. 确认对话框
   ======================================================== */
html[data-theme="dark"] .rong-messagebox {
    color: #d4d4d4 !important;
}
html[data-theme="dark"] .rong-messagebox-bd {
    color: #b0b0b0 !important;
}

/* ========================================================
   45. 全屏搜索面板 .rong-search-result (全局搜索弹出层)
   原色: background: #fff; border-right: 1px solid #e3e3e3
   ======================================================== */
html[data-theme="dark"] .rong-search-result {
    background: #2b2b2b !important;
    border-right-color: #3a3a3a !important;
    color: #d4d4d4 !important;
}

/* 搜索内容区域 */
html[data-theme="dark"] .rong-search-content {
    background-color: #2b2b2b !important;
    color: #d4d4d4 !important;
}

/* 搜索标签/Tab栏 (全部、联系人、职位、组织架构 等) */
html[data-theme="dark"] .rong-search-label {
    border-bottom-color: #3a3a3a !important;
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-search-label a {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-search-label a:hover {
    color: #56b0ff !important;
}
html[data-theme="dark"] .rong-search-label .rong-selected,
html[data-theme="dark"] .rong-search-label a.rong-selected {
    color: #56b0ff !important;
}

/* 搜索历史标题 "搜索历史" */
html[data-theme="dark"] .rong-search-content h3,
html[data-theme="dark"] .rong-search-content h4 {
    color: #d4d4d4 !important;
}

/* 搜索历史标签 (小圆角按钮，如 "朱枫"、"sjw" 等) */
html[data-theme="dark"] .rong-search-content span,
html[data-theme="dark"] .rong-search-content .rong-search-record-list li {
    color: #b0b0b0 !important;
}

/* 搜索结果列表 */
html[data-theme="dark"] .rong-search-result .rong-group-userlist-bd {
    background-color: #2b2b2b !important;
}
html[data-theme="dark"] .rong-search-result .rong-group-userlist-bd li:hover {
    background-color: #333333 !important;
}

/* 搜索返回按钮 */
html[data-theme="dark"] .rong-search-back {
    color: #56b0ff !important;
}

/* 搜索分隔线 */
html[data-theme="dark"] .rong-search-members-hd {
    border-bottom-color: #3a3a3a !important;
    color: #8a8a8a !important;
}

/* 搜索结果项高亮文字 */
html[data-theme="dark"] .rong-search-summary em,
html[data-theme="dark"] .rong-search-empty em,
html[data-theme="dark"] .rong-search-members .rong-profile-main em {
    color: #56b0ff !important;
}

/* ========================================================
   46. 对话框内搜索 .rong-dialog-search
   ======================================================== */
html[data-theme="dark"] .rong-dialog-search {
    background-color: #2f2f2f !important;
}
html[data-theme="dark"] .rong-dialog-searchdetail {
    background-color: transparent !important;
}
html[data-theme="dark"] .rong-dialog-searchdetail > div > ul {
    color: #ffffff !important;
}
html[data-theme="dark"] .rong-dialog-searchdetail .search-record h6 {
    color: #ffffff !important;
}
html[data-theme="dark"] .rong-dialog-searchdetail .search-record ul li {
    color: #ffffff !important;
}

/* ========================================================
   47. 群组对话框 / 组织架构对话框
   ======================================================== */
html[data-theme="dark"] .rong-group-dialog .rong-dialog-bd,
html[data-theme="dark"] .rong-group-create,
html[data-theme="dark"] .rong-group-remove {
    background-color: #2f2f2f !important;
}
html[data-theme="dark"] .rong-group-selected-hd {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-group-selected-bd {
    background-color: #2f2f2f !important;
}
html[data-theme="dark"] .rong-group-userlist-bd .rong-selected {
    background-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-group-buttons {
    border-top-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-group-name {
    border-top-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-group-title span {
    color: #8a8a8a !important;
}

/* 群组搜索区域 */
html[data-theme="dark"] .rong-group-search-bd {
    background-color: #2f2f2f !important;
}
html[data-theme="dark"] .rong-group-search-field input {
    background-color: #333333 !important;
    color: #d4d4d4 !important;
    border-color: #4a4a4a !important;
}

/* ========================================================
   48. 面包屑导航
   ======================================================== */
html[data-theme="dark"] .rong-dialog-crumb {
    border-bottom-color: #3a3a3a !important;
}
html[data-theme="dark"] .rong-crumb {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-crumb a {
    color: #56b0ff !important;
}

/* ========================================================
   49. 收藏对话框
   ======================================================== */
html[data-theme="dark"] .rong-dialog-inner-collect {
    background: #2f2f2f !important;
    border-color: #3f3f3f !important;
    box-shadow: 0 4px 16px rgba(0,0,0,0.5) !important;
}
html[data-theme="dark"] .rong-collect-selected {
    background: #3a3a3a !important;
}
html[data-theme="dark"] .rong-collect-dialog-content {
    color: #d4d4d4 !important;
}
html[data-theme="dark"] .rong-collect-dialog-content .rong-collect-dialog-user {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-collect-dialog-content .rong-collect-dialog-border {
    border-top-color: #3a3a3a !important;
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-collect-list-border {
    border-bottom-color: #3a3a3a !important;
}

/* ========================================================
   50. 同步数据 / 锁屏面板
   ======================================================== */
html[data-theme="dark"] .rong-syncdata {
    background-color: #2b2b2b !important;
}
html[data-theme="dark"] .rong-device-lock-dialog {
    background-color: #2b2b2b !important;
}
html[data-theme="dark"] .rong-device-lock-text {
    color: #d4d4d4 !important;
}
html[data-theme="dark"] .rong-device-lock-note {
    color: #8a8a8a !important;
}

/* ========================================================
   51. 对话框加载遮罩
   ======================================================== */
html[data-theme="dark"] .rong-dialog-loading {
    background: rgba(30, 30, 30, 0.5) !important;
}

/* ========================================================
   52. 部门路径文字
   ======================================================== */
html[data-theme="dark"] .rong-dept-path {
    color: #8a8a8a !important;
}

/* ========================================================
   53. 通用二级文字颜色
   ======================================================== */
html[data-theme="dark"] .rong-no-more {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-search-title {
    color: #d4d4d4 !important;
}
html[data-theme="dark"] .rong-search-pathname {
    color: #8a8a8a !important;
}
html[data-theme="dark"] .rong-group-nickname-box .rong-group-nickname-show {
    color: #d4d4d4 !important;
}
        `;
    },

    // ---- 切换过渡动画 CSS ----
    _getTransitionCSS() {
        return `
            html.dark-mode-transitioning,
            html.dark-mode-transitioning *,
            html.dark-mode-transitioning *::before,
            html.dark-mode-transitioning *::after {
                transition: background-color 0.3s ease,
                            color 0.3s ease,
                            border-color 0.3s ease,
                            box-shadow 0.3s ease !important;
            }
        `;
    },

    // ---- 系统主题检测 ----
    _getSystemTheme() {
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    },

    // ---- 根据偏好计算实际显示模式 ----
    _resolveEffectiveMode(pref) {
        if (pref === 'system') return this._getSystemTheme();
        return pref === 'dark' ? 'dark' : 'light';
    },

    // ---- 应用实际显示模式（dark/light） ----
    _applyTheme(effectiveMode, animate = true) {
        const html = document.documentElement;
        if (animate) {
            html.classList.add('dark-mode-transitioning');
            setTimeout(() => html.classList.remove('dark-mode-transitioning'), 400);
        }
        if (effectiveMode === 'dark') {
            html.setAttribute('data-theme', 'dark');
        } else {
            html.removeAttribute('data-theme');
        }
    },

    // ---- 监听系统主题变化 ----
    _setupSystemListener(instance, pref) {
        // 清理旧监听器
        if (instance._systemMediaQuery && instance._systemListener) {
            instance._systemMediaQuery.removeEventListener('change', instance._systemListener);
            instance._systemListener = null;
        }
        // 仅在跟随系统模式下监听
        if (pref === 'system') {
            const mq = window.matchMedia('(prefers-color-scheme: dark)');
            const self = this;
            const listener = (e) => {
                console.log(`[DarkMode] 系统主题变化: ${e.matches ? 'dark' : 'light'}`);
                self._applyTheme(e.matches ? 'dark' : 'light', true);
            };
            mq.addEventListener('change', listener);
            instance._systemMediaQuery = mq;
            instance._systemListener = listener;
        }
    },

    // ---- 插件生命周期 ----
    async init(config, pluginManager) {
        console.log('[DarkMode] 🚀 初始化日夜间模式插件 v4.0...');
        console.log('[DarkMode] 收到的配置:', JSON.stringify(config));

        const instance = {
            _systemMediaQuery: null,
            _systemListener: null,
        };

        // 1. 注入暗色模式样式表
        if (!document.getElementById(this.STYLE_ID)) {
            const style = document.createElement('style');
            style.id = this.STYLE_ID;
            style.textContent = this._getDarkModeCSS();
            document.head.appendChild(style);
        }

        // 2. 注入过渡动画样式
        if (!document.getElementById(this.TRANSITION_STYLE_ID)) {
            const transStyle = document.createElement('style');
            transStyle.id = this.TRANSITION_STYLE_ID;
            transStyle.textContent = this._getTransitionCSS();
            document.head.appendChild(transStyle);
        }

        // 3. 读取配置面板中的模式偏好
        const modePref = config.mode || 'system';
        const effective = this._resolveEffectiveMode(modePref);
        this._applyTheme(effective, false);

        // 4. 如果是跟随系统，设置监听器
        this._setupSystemListener(instance, modePref);

        console.log(`[DarkMode] ✅ 插件已启动 (偏好: ${modePref}, 实际: ${effective})`);
        return instance;
    },

    async destroy(instance) {
        console.log('[DarkMode] 🔄 销毁日夜间模式插件...');

        // 恢复日间模式
        document.documentElement.removeAttribute('data-theme');

        // 移除系统主题监听器
        if (instance._systemMediaQuery && instance._systemListener) {
            instance._systemMediaQuery.removeEventListener('change', instance._systemListener);
        }

        // 移除样式
        [this.STYLE_ID, this.TRANSITION_STYLE_ID].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.remove();
        });

        document.documentElement.classList.remove('dark-mode-transitioning');
        console.log('[DarkMode] ✅ 插件已销毁');
    }
};
